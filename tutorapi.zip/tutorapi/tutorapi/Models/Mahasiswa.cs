﻿namespace tutorapi.Models
{
    public class Mahasiswa
    {
        public int id {  get; set; }
        public string nama { get; set; }
        public string NIM {  get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string foto { get; set; }
        public string remember_token { get; set; }
    }
}
