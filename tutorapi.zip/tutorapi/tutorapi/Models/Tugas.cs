﻿namespace tutorapi.Models
{
    public class Tugas
    {
        public int id { get; set; }
        public string judul {  get; set; }
        public string deskripsi { get; set; }
        public string file_tugas {  get; set; }
    }
}
