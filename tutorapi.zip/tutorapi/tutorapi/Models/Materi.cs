﻿namespace tutorapi.Models
{
    public class Materi
    {
        public int id { get; set; }
        public string judul {  get; set; }
        public string deskripsi {  get; set; }
        public string minggu_ke {  get; set; }
        public string file_materi { get; set; }
    }
}
